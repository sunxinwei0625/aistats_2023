'5_simulation_new.py' outputs the results in 'results_new.csv'

'5_simulation_1_summary.R' outputs the summarizing plot 'plot_simulation.pdf'